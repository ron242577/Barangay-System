<?php
session_start();
include "db.php";

if (isset($_POST['submit'])) {

    $user_id = $_SESSION['user_id'];

    $document = $_POST['docs'];
    $fullname = $_POST['fullname'];
    $address = $_POST['address'];
    $purpose = $_POST['purpose'];

    $guardian_name = $_POST['guardian_name'] ?? NULL;
    $guardian_address = $_POST['guardian_address'] ?? NULL;
    $guardian_contact = $_POST['guardian_contact'] ?? NULL;

    $sql = "INSERT INTO requests 
    (user_id, document_type, fullname, address, purpose, guardian_name, guardian_address, guardian_contact)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "isssssss",
        $user_id,
        $document,
        $fullname,
        $address,
        $purpose,
        $guardian_name,
        $guardian_address,
        $guardian_contact
    );

    if ($stmt->execute()) {
        echo "<script>alert('Request submitted successfully!');</script>";
    } else {
        echo "<script>alert('Error submitting request');</script>";
    }
}
?>




<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Barangay 292 - Homepage</title>
   <link rel="stylesheet" href="homepage.css">
   <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
</head>

<body>

<div class="main">

  <div class="sidebar">

           <div class="usercontainer">
            <img class="user"src="images/usericon.png" alt="Notification" /> 
           </div>
             
                <h4 class="username"><?= htmlspecialchars($_SESSION["fullname"]) ?></h4> 
             
                    <div class="residentcontainer">
                    <h4 class="resident"><?= htmlspecialchars($_SESSION["role"]) ?></h4>
                    </div>

                        <hr class="hrside">

                            <div class="btncontainer" onclick="showHome()">
                            <img class="icon"src="images/homeicon.png" alt="home" /> 
                            <h4 class="text">Home</h4>
                            </div>

                            <div class="btncontainer" onclick="showRequest()">
                            <img class="icon"src="images/reqicon.png" alt="request" /> 
                            <h4 class="text">Request</h4>
                            </div>

                            <div class="btncontainer" onclick="showReport()">
                            <img class="icon"src="images/repicon.png" alt="request" /> 
                            <h4 class="text">Report</h4>
                            </div>

                            <div class="btncontainer" onclick="showDonate()">
                            <img class="icon"src="images/dicon.png" alt="request" /> 
                            <h4 class="text">Donate</h4>
                            </div>

                            <div class="btncontainer" onclick="showFeedback()">
                            <img class="icon"src="images/fbicon.png" alt="request" /> 
                            <h4 class="text">Feedback</h4>
                            </div>
        
                                <div class="logoutcontainer" onclick="window.location.href='logout.php'">

                                 <h4 class="logout">Logout</h4>
                                </div>                                  

  </div>

    <div class="header">
        <div class="child1">
            <div>
             <img class="logo"src="images/logo2.png" alt="logo" />
            </div>
                <h3 class="h3top">Barangay management & E-Services Platform</h3>
                <img class="notif"src="images/notification.png" alt="Notification" />
        </div>

            <hr class="hrtop1">

                <div class="main2">
                    <div class="home" id="home">
                        <h4>Barangay 292</h4>
                        <hr class="hr1">
                            <div class="content3">
                                    <div class="descrip">
                                     <p class="par1">Barangay 292 is hdhaasdasdhasdasd ashdasdbasd ashasdhas ashasdjhasb ashaksja schasbcajsc aschabscjasc ascjhasjca scashcajsc ascjasca scajsbcjas cascbas cascba scajscbas casjcba scajsc ascnasc acknasc asca casc ascascasc ascascasc acac acacacac acac aca caca caca </p>
                                    </div>

                                    <div class="image-container">
                                    <img class="barangay"src="images/barangay.jpg" alt="Barangay" />
                                    </div>
                            </div>

                                     <div class="content4">

                                        <div class ="announcement">                    
                                        <h4 class="h41">Announcement</h4>
                                        <hr class="hr2">
                                        <textarea class=textareaannouncement></textarea>  
                                        </div>

                                            <div class="emergency">
                                            <h4 class="h42">Emergency Hotlines</h4>
                                            <hr class="hr3">
                                            <p class="par2">Barangay Hall: 123-2122-232<br>Police Station: 123-2122-232<br>Hospital: 123-2122-232<br>Fire Emergency: 123-2122-232 </p>
                                            </div>

                                    </div>
                                   
            
                    </div>

 <div class="request" id="request">
    <h4>Request Form</h4>
    <hr class="hr1">

    <form method="POST" action="">
        <div class="formcontainer">
            <div class="minform">

                <label>Document:</label>
                <select name="docs" id="docs" onchange="toggle(this)">
                    <option value="Barangay Clearance">Barangay Clearance</option>
                    <option value="Barangay Indigency">Barangay Indigency</option>
                    <option value="Barangay ID">Barangay ID</option>
                    <option value="First Time Job Seeker">First Time Job-Seeker</option>
                </select>

                <br><br>

                <label>Full Name</label><br>
                <input type="text" name="fullname" required><br><br>

                <label>Address</label><br>
                <input type="text" name="address" required><br><br>

                <label>Purpose</label><br>
                <input type="text" name="purpose" required><br><br>

                <!-- GUARDIAN (ONLY FOR BARANGAY ID) -->
                <div id="miniform2" style="display:none;">
                    <label>Guardian Name</label><br>
                    <input type="text" name="guardian_name"><br><br>

                    <label>Guardian Address</label><br>
                    <input type="text" name="guardian_address"><br><br>

                    <label>Guardian Contact</label><br>
                    <input type="text" name="guardian_contact"><br><br>
                </div>

            </div>
        </div>

        <div class="submitcontainer">
            <input type="submit" name="submit" value="Submit">
        </div>
    </form>
</div>


 <div class="report" id="report">
    <h4>Report</h4>
     <hr class="hr1">
        <form>
            <div class="formcontainerReport">
                <div class="minformReport">
                    <label class="doclistReport" for="cars">Reason:</label>
                     <select class="docselectReport" name="docsReport" id="docsReport">
                     <option value="brgyClearance">Noise Disturbance</option>
                     <option value="brgyIndigency">Illegal Parking</option>
                     <option value="brgyId">Loitering</option>
                      <option value="Ftjs">Vandalism</option>
                       <option value="Ftjs">Domestic Dispute</option>
                        <option value="Ftjs">Suspicious Activity</option>
                          <option value="Ftjs">Others</option>

                     </select>

                        <div class="notecontainerReport">
                            <p class="noteReport"><b>Important Notice:</b> Some report reasons may require proof and verification before any action is taken by the Barangay. Please ensure that all information provided is accurate and truthful, as any false, misleading, or troll reports may result in proper compensation or penalties in accordance with Barangay rules and regulations. If you do not know the name of the person being reported, you may leave it blank and instead provide the complete address and clear details to help with verification.</p>
                        </div>
                            <div class="miniformReport">
                                <div class="miniform1">
                                    <label for="Name" class="Reasontext">Reason</label><br>
                                    <input class="Reasontextbox" type="textbox" id="Name" name="name">
                                    <br>

                                    <label for="Address" class="persontext">Person Being Reported</label><br>
                                    <input class="persontextbox" type="textbox" id="Address" name="address">
                                    <br>

                                    <label for="Address" class="addressReporttext">Address</label><br>
                                    <input class="nametextbox" type="textbox" id="Address" name="address">
                                </div>

                                <div class="miniform3">
                                    <label for="Purpose" class="prooftext">Proof</label><br>
                                    <input class="podfileproof" type="file" id="Purpose" name="purpose">
                                    <br>

                                    <label for="Purpose" class="specifytext">Specify</label><br>
                                    <div class="specifyReportdiv">
                                    <textarea class="specifyReport" type="textarea" id="Purpose" name="purpose"></textarea></div>
                                </div>    
                            </div>
                </div>
            </div>
               
                <div class="submitcontainerReport">
                    <input type="submit" class="btnsubmitReport" value ="Submit" name="submit" id="idsubmit">
                </div>
              
        </form>
 </div>
                     
<div class="donate" id="donate"> 
    <h4>Donate</h4>
    <hr class="hr1">
        <form>
             <div class="donatecontainer">
                <div class="donatetext">
                    <p class="dtext"><b class="bold">Help Support Our Barangay</b><br>
                    Your generosity helps us improve community programs, maintain public spaces, and support initiatives that benefit everyone. Every contribution big or small creates a meaningful impact in strengthening our Barangay.<br><br>
                    You may also include a short message or specify the purpose of your donation in the space provided below whether it is for community projects, emergency assistance, youth programs, or other causes close to your heart. This helps ensure your donation is directed where it is needed most.
                    </p>
                    <textarea name="donatetextarea" class="donatetextarea"> </textarea>
                </div>

                    <div class="qrdonatecontainer">
                        <img class="qrlogo"src="images/qr.png" alt="Barangay" />
                        <div class="labeldonate"><label for="Pod" class="podtext">Upload Proof of Donation</label></div><br>
                         <input class="podfile" type="file" id="Pod" name="pod">
                    </div>
            </div>
             
                <div class="dsubmitcontainer">
                    <input class="donatesubmit" type="submit" value="Submit">
                </div>
               
        </form>
</div>

<div class="feedback" id="feedback">
    <h4>Feedback</h4>
    <hr class="hr1">
        <form> 
            <div class="feedbackcontainer">
                <div class="feedbacktext">
                    <p class="ptext"><b class="bold">Help us shape the future of our Barangay</b><br>
                    Share your ideas, suggestions, and feedback on community life or ways we can make our online platform better. Together, let's build a more vibrant community both offline and online.<br><br>
                    By working collaboratively, we can foster a safe, inclusive, and supportive space where everyone feels heard, connected, and empowered to participate and contribute.
                    </p>
                </div>

                
            </div>

                <textarea name="feedbackta" class="textarea"> </textarea>

                   <div class="fbsubmitcontainer">
                        <input class="feedbacksubmit" type="submit" value="Submit">
                    </div>
                   
        </form>
</div>

<div class="content2">
    <div class="officials" id="brgyofficials">
        <div class="officialtextcontainer">
            <h4 class="brgyofficialtext">Barangay Officials</h4>
        </div>
        <hr class="hr5">
            <div class="officials-list">
                <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5 >Hance Kerwin Santos GAW<br><i>Chairman</i></h5>  
                    </div>
                </div>

                  <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Claire Agotero Valbuena<br><i>Secretary</i></h5>    
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Alexander Tio Chua<br><i>Treasurer</i></h5>
                    </div>
                </div>
               
                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Helen Uy Tio<br><i>Kagawad</i></h5>
                    </div>
                </div>

                  <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Alvin Glenn Lau Pua<br><i>Kagawad</i></h5>
                    </div>
                </div>

                  <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Antonio Co Cua Lee<br><i>Kagawad</i></h5>
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Corazon Pua Sia<br><i>Kagawad</i></h5>                  
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Aarone Kedrick Calijan Teng<br><i>Kagawad</i></h5>                   
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Alexander Ho Sia<br><i>Kagawad</i></h5>                   
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Gilbert Tio Laddaran<br><i>Kagawad</i></h5>                
                    </div>
                </div>

            </div>
              <hr class="hr6">
              <div class="skcontainer" id="officials" onclick="showSK()">
                <button>View SK Officials</button>
              </div>
                   
    </div>
    <div class="officials2" id="brgyskofficials">
        <div class="skofficialtextcontainer">
            <h4 class="sktext">SK Officials</h4>
        </div>
        <hr class="hr5">
            <div class="officials-list">
                <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Emily Charr Villaram<br><i>SK Chairman</i></h5>  
                    </div>
                </div>

                  <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Maxine Sabile<br><i>SK Secretary</i></h5>    
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Rea Jean Gabo<br><i>SK Treasurer</i></h5>
                    </div>
                </div>
               
                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Divine Abanador<br><i>SK Kagawad</i></h5>
                    </div>
                </div>

                  <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Darrly Teng<br><i>SK Kagawad</i></h5>
                    </div>
                </div>

                  <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Baby Joy Atibagos<br><i>SK Kagawad</i></h5>
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Quinnie Perante<br><i>SK Kagawad</i></h5>                  
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Alvin Abrique<br><i>SK Kagawad</i></h5>                   
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Sheila Salagantin<br><i>SK Kagawad</i></h5>                   
                    </div>
                </div>

                 <div class = "pics">
                    <img class="pic"src="images/divine.jpg" alt="request" /> 
                    <div class="h5container">
                    <h5>Christian Magtubo<br><i>SK Kagawad</i></h5>                
                    </div>
                </div>

            </div>
              <hr class="hr6">
              <div class="skcontainer" id="officials2" onclick="showOfficials()">
                <button>View Officials</button>
              </div>
                   
    </div>
   
   <div class="botright">
        <p class="pbr">806 Alvarado Street Binondo, Metro Manila</p>
                
        <img class="bot"src="images/instagram.png" alt="home" /> 
        <img class="bot"src="images/gmail.png" alt="home" /> 
        <img class="bot"src="images/facebook.png" alt="home" /> 
                  
    </div>      
</div>
                </div>
    </div>
</div>
<script>
    function showHome() {
    document.getElementById("home").style.display = "block";
    document.getElementById("request").style.display = "none";
    document.getElementById("report").style.display = "none";
    document.getElementById("donate").style.display = "none";
    document.getElementById("feedback").style.display = "none";
}
function showRequest() {
     document.getElementById("home").style.display = "none";
    document.getElementById("request").style.display = "block";
    document.getElementById("report").style.display = "none";
    document.getElementById("donate").style.display = "none";
    document.getElementById("feedback").style.display = "none";
}
function showReport() {
     document.getElementById("home").style.display = "none";
    document.getElementById("request").style.display = "none";
    document.getElementById("report").style.display = "block";
    document.getElementById("donate").style.display = "none";
    document.getElementById("feedback").style.display = "none";
}
function showDonate() {
     document.getElementById("home").style.display = "none";
    document.getElementById("request").style.display = "none";
    document.getElementById("report").style.display = "none";
    document.getElementById("donate").style.display = "block";
    document.getElementById("feedback").style.display = "none";
}
function showFeedback() {
     document.getElementById("home").style.display = "none";
    document.getElementById("request").style.display = "none";
    document.getElementById("report").style.display = "none";
    document.getElementById("donate").style.display = "none";
    document.getElementById("feedback").style.display = "block";
}
function showSK() {
     document.getElementById("brgyofficials").style.display = "none";
    document.getElementById("brgyskofficials").style.display = "block";
}
function showOfficials() {
     document.getElementById("brgyofficials").style.display = "block";
    document.getElementById("brgyskofficials").style.display = "none";
}

  const buttons = document.querySelectorAll('.btncontainer');

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  function toggle(select){
  const miniform2 = document.getElementById("miniform2");
  if(select.value === "brgyId"){
    miniform2.style.display = "inline-block";
  } else {
      miniform2.style.display = "none";
  }
}

</script>

</body>
</html>