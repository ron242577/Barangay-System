<?php
session_start();
include "db.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Personal info
    $firstName  = trim($_POST["firstName"] ?? "");
    $middleName = trim($_POST["middleName"] ?? "");
    $lastName   = trim($_POST["lastName"] ?? "");
    $fullname   = trim($firstName . " " . $middleName . " " . $lastName);

    $birthdate   = $_POST["birthdate"] ?? null;
    $gender      = $_POST["gender"] ?? null;
    $civilStatus = $_POST["civilStatus"] ?? null;

    // Contact info
    $address = trim($_POST["address"] ?? "");
    $phone   = trim($_POST["contactNumber"] ?? "");
    $email   = trim($_POST["email"] ?? "");

    // Account info
    $username = trim($_POST["username"] ?? "");
    $password = trim($_POST["password"] ?? "");

    // Household / flags
    $isf           = $_POST["isf"] ?? null;
    $householdHead = trim($_POST["householdHead"] ?? "");
    $pwd           = $_POST["pwd"] ?? null;
    $soloParent    = $_POST["soloParent"] ?? null;

    $role   = "resident";
    $status = "active"; // allow login immediately

    // ===== FILE UPLOADS =====
    $uploadDir = "uploads/ids/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $pwdProofPath = null;
    if (!empty($_FILES["pwdProof"]["name"])) {
        $ext = strtolower(pathinfo($_FILES["pwdProof"]["name"], PATHINFO_EXTENSION));
        $pwdProofPath = $uploadDir . "pwd_" . time() . "." . $ext;
        move_uploaded_file($_FILES["pwdProof"]["tmp_name"], $pwdProofPath);
    }

    $soloParentProofPath = null;
    if (!empty($_FILES["soloParentProof"]["name"])) {
        $ext = strtolower(pathinfo($_FILES["soloParentProof"]["name"], PATHINFO_EXTENSION));
        $soloParentProofPath = $uploadDir . "solo_" . time() . "." . $ext;
        move_uploaded_file($_FILES["soloParentProof"]["tmp_name"], $soloParentProofPath);
    }

    // ===== DUPLICATE CHECK =====
    
        $check = $conn->prepare(
    "SELECT id FROM accounts WHERE email = ? OR username = ? OR phone = ?"
        );

        $check->bind_param("sss", $email, $username, $phone);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = "⚠ Email, username, or contact number already exists.";
        } else {

        // ===== INSERT ACCOUNT =====
        $stmt = $conn->prepare(
            "INSERT INTO accounts 
            (fullname, birthdate, gender, civil_status, address, phone, email, username, password,
             isf, household_head, pwd, solo_parent, pwd_proof, solo_parent_proof, role, status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        );

        $stmt->bind_param(
            "sssssssssssssssss",
            $fullname,
            $birthdate,
            $gender,
            $civilStatus,
            $address,
            $phone,
            $email,
            $username,
            $password,
            $isf,
            $householdHead,
            $pwd,
            $soloParent,
            $pwdProofPath,
            $soloParentProofPath,
            $role,
            $status
        );

        if ($stmt->execute()) {
            $message = "✅ Registration successful! You can now log in.";
        } else {
            $message = "❌ Registration failed: " . $stmt->error;
        }

        $stmt->close();
    }

    $check->close();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Barangay 292 E-Services</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'DM Sans', sans-serif;
            background: linear-gradient(135deg, #2d7a3e 0%, #1a4d2e 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }

        .register-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 900px;
            margin: 0 auto;
            overflow: hidden;
        }

        .register-header {
            background: linear-gradient(135deg, #2d7a3e 0%, #1a4d2e 100%);
            padding: 40px;
            text-align: center;
            color: white;
        }

        .logo {
            width: 80px;
            height: 80px;
            background: white;
            border-radius: 50%;
            padding: 10px;
            margin: 0 auto 20px;
        }

        .register-header h1 {
            font-size: 32px;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .register-header p {
            font-size: 16px;
            opacity: 0.95;
        }

        .register-form {
            padding: 50px;
        }

        .form-section {
            margin-bottom: 35px;
        }

        .section-title {
            font-size: 20px;
            color: #1a4d2e;
            margin-bottom: 20px;
            font-weight: 700;
            padding-bottom: 10px;
            border-bottom: 2px solid #e0e0e0;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 14px;
        }

        .form-group label .required {
            color: #dc3545;
            margin-left: 3px;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"],
        .form-group input[type="tel"],
        .form-group input[type="date"],
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s ease;
            font-family: 'DM Sans', sans-serif;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2d7a3e;
            box-shadow: 0 0 0 3px rgba(45, 122, 62, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .radio-group {
            display: flex;
            gap: 30px;
            margin-top: 10px;
        }

        .radio-option {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .radio-option input[type="radio"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
            accent-color: #2d7a3e;
        }

        .radio-option label {
            margin: 0;
            cursor: pointer;
            font-weight: 400;
        }

        .file-input-wrapper {
            position: relative;
            margin-top: 10px;
        }

        .file-input-wrapper input[type="file"] {
            padding: 10px;
            border: 2px dashed #e0e0e0;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
        }

        .file-input-wrapper input[type="file"]::-webkit-file-upload-button {
            background: #2d7a3e;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            margin-right: 10px;
        }

        .helper-text {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }

        .error-message {
            color: #dc3545;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }

        .register-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #2d7a3e 0%, #1a4d2e 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            font-family: 'DM Sans', sans-serif;
            margin-top: 20px;
        }

        .register-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(45, 122, 62, 0.3);
        }

        .register-btn:active {
            transform: translateY(0);
        }

        .login-link {
            text-align: center;
            margin-top: 25px;
            font-size: 14px;
            color: #666;
        }

        .login-link a {
            color: #2d7a3e;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .login-link a:hover {
            color: #1a4d2e;
        }

        @media (max-width: 768px) {
            .register-form {
                padding: 30px 20px;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .register-header h1 {
                font-size: 26px;
            }

            .section-title {
                font-size: 18px;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-header">
            <img class="logo" src="images/logo2.png" alt="Barangay 292 Logo" onerror="this.style.display='none'">
            <h1>Barangay 292 Registration</h1>
            <p>Create your account to access barangay services</p>
        </div>

        <div class="register-form">
            <form id="registerForm" method="POST" action="" enctype="multipart/form-data">
                
                <!-- Personal Information Section -->
                <div class="form-section">
                    <h2 class="section-title">Personal Information</h2>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="firstName">First Name <span class="required">*</span></label>
                            <input type="text" id="firstName" name="firstName" required>
                            <span class="error-message" id="firstNameError">Please enter your first name</span>
                        </div>

                        <div class="form-group">
                            <label for="middleName">Middle Name</label>
                            <input type="text" id="middleName" name="middleName">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="lastName">Last Name <span class="required">*</span></label>
                            <input type="text" id="lastName" name="lastName" required>
                            <span class="error-message" id="lastNameError">Please enter your last name</span>
                        </div>

                        <div class="form-group">
                            <label for="birthdate">Date of Birth <span class="required">*</span></label>
                            <input type="date" id="birthdate" name="birthdate" required>
                            <span class="error-message" id="birthdateError">Please select your birthdate</span>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="gender">Gender <span class="required">*</span></label>
                            <select id="gender" name="gender" required>
                                <option value="">Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Prefer not to say</option>
                            </select>
                            <span class="error-message" id="genderError">Please select your gender</span>
                        </div>

                        <div class="form-group">
                            <label for="civilStatus">Civil Status <span class="required">*</span></label>
                            <select id="civilStatus" name="civilStatus" required>
                                <option value="">Select Civil Status</option>
                                <option value="single">Single</option>
                                <option value="married">Married</option>
                                <option value="widowed">Widowed</option>
                                <option value="separated">Separated</option>
                            </select>
                            <span class="error-message" id="civilStatusError">Please select your civil status</span>
                        </div>
                    </div>
                </div>

                <!-- Contact Information Section -->
                <div class="form-section">
                    <h2 class="section-title">Contact Information</h2>
                    
                    <div class="form-group full-width">
                        <label for="address">Complete Address <span class="required">*</span></label>
                        <textarea id="address" name="address" required></textarea>
                        <span class="error-message" id="addressError">Please enter your complete address</span>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="contactNumber">Contact Number <span class="required">*</span></label>
                            <input type="tel" id="contactNumber" name="contactNumber" placeholder="09XX-XXX-XXXX" required>
                            <span class="error-message" id="contactError">Please enter a valid contact number</span>
                        </div>

                        <div class="form-group">
                            <label for="email">Email Address <span class="required">*</span></label>
                            <input type="email" id="email" name="email" required>
                            <span class="error-message" id="emailError">Please enter a valid email address</span>
                        </div>
                    </div>
                </div>

                <!-- Account Information Section -->
                <div class="form-section">
                    <h2 class="section-title">Account Information</h2>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="username">Username <span class="required">*</span></label>
                            <input type="text" id="username" name="username" required>
                            <span class="error-message" id="usernameError">Please enter a username</span>
                        </div>

                        <div class="form-group">
                            <label for="password">Password <span class="required">*</span></label>
                            <input type="password" id="password" name="password" required>
                            <span class="error-message" id="passwordError">Password must be at least 8 characters</span>
                        </div>
                    </div>

                    <div class="form-group full-width">
                        <label for="confirmPassword">Confirm Password <span class="required">*</span></label>
                        <input type="password" id="confirmPassword" name="confirmPassword" required>
                        <span class="error-message" id="confirmPasswordError">Passwords do not match</span>
                    </div>
                </div>

                <!-- Household Information Section -->
                <div class="form-section">
                    <h2 class="section-title">Household Information</h2>
                    
                    <div class="form-group full-width">
                        <label>Are you an Informal Settler Family (ISF) member? <span class="required">*</span></label>
                        <div class="radio-group">
                            <div class="radio-option">
                                <input type="radio" id="isfYes" name="isf" value="yes" required>
                                <label for="isfYes">Yes</label>
                            </div>
                            <div class="radio-option">
                                <input type="radio" id="isfNo" name="isf" value="no" required>
                                <label for="isfNo">No</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group full-width">
                        <label for="householdHead">Parent / Household Head Name <span class="required">*</span></label>
                        <input type="text" id="householdHead" name="householdHead" required>
                        <span class="helper-text">If you are the household head, enter your own name</span>
                        <span class="error-message" id="householdHeadError">Please enter household head name</span>
                    </div>
                </div>

                <!-- PWD Section -->
                <div class="form-section">
                    <h2 class="section-title">Person with Disability (PWD)</h2>
                    
                    <div class="form-group full-width">
                        <label>Are you a Person with Disability (PWD)? <span class="required">*</span></label>
                        <div class="radio-group">
                            <div class="radio-option">
                                <input type="radio" id="pwdYes" name="pwd" value="yes" required onchange="togglePwdProof()">
                                <label for="pwdYes">Yes</label>
                            </div>
                            <div class="radio-option">
                                <input type="radio" id="pwdNo" name="pwd" value="no" required onchange="togglePwdProof()">
                                <label for="pwdNo">No</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group full-width" id="pwdProofSection" style="display: none;">
                        <label for="pwdProof">PWD ID or Medical Certificate</label>
                        <div class="file-input-wrapper">
                            <input type="file" id="pwdProof" name="pwdProof" accept=".pdf,.jpg,.jpeg,.png">
                        </div>
                        <span class="helper-text">Upload PWD ID or medical certificate (PDF, JPG, PNG - Max 5MB)</span>
                    </div>
                </div>

                <!-- Solo Parent Section -->
                <div class="form-section">
                    <h2 class="section-title">Solo Parent</h2>
                    
                    <div class="form-group full-width">
                        <label>Are you a Solo Parent? <span class="required">*</span></label>
                        <div class="radio-group">
                            <div class="radio-option">
                                <input type="radio" id="soloParentYes" name="soloParent" value="yes" required onchange="toggleSoloParentProof()">
                                <label for="soloParentYes">Yes</label>
                            </div>
                            <div class="radio-option">
                                <input type="radio" id="soloParentNo" name="soloParent" value="no" required onchange="toggleSoloParentProof()">
                                <label for="soloParentNo">No</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group full-width" id="soloParentProofSection" style="display: none;">
                        <label for="soloParentProof">Solo Parent ID or Certificate</label>
                        <div class="file-input-wrapper">
                            <input type="file" id="soloParentProof" name="soloParentProof" accept=".pdf,.jpg,.jpeg,.png">
                        </div>
                        <span class="helper-text">Upload Solo Parent ID or certificate (PDF, JPG, PNG - Max 5MB)</span>
                    </div>
                </div>
                <?php if (!empty($message)): ?>
                <div style="margin-bottom:20px;
                padding:12px;
                border-radius:8px;
                font-weight:600;
                text-align:center;
                color: <?= str_starts_with($message, "✅") ? "#155724" : "#721c24" ?>;
                background: <?= str_starts_with($message, "✅") ? "#d4edda" : "#f8d7da" ?>;">
                <?= htmlspecialchars($message) ?>
                </div>
                <?php endif; ?>

                <button type="submit" class="register-btn">Register Account</button>

                <div class="login-link">
                    Already have an account? <a href="login.php">Login here</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Toggle PWD proof section
        function togglePwdProof() {
            const pwdYes = document.getElementById('pwdYes');
            const pwdProofSection = document.getElementById('pwdProofSection');
            
            if (pwdYes.checked) {
                pwdProofSection.style.display = 'block';
            } else {
                pwdProofSection.style.display = 'none';
                document.getElementById('pwdProof').value = '';
            }
        }

        // Toggle Solo Parent proof section
        function toggleSoloParentProof() {
            const soloParentYes = document.getElementById('soloParentYes');
            const soloParentProofSection = document.getElementById('soloParentProofSection');
            
            if (soloParentYes.checked) {
                soloParentProofSection.style.display = 'block';
            } else {
                soloParentProofSection.style.display = 'none';
                document.getElementById('soloParentProof').value = '';
            }
        }

        // Form validation
        const registerForm = document.getElementById('registerForm');
        
        registerForm.addEventListener('submit', function(e) {
            let isValid = true;

            // Reset all error messages
            document.querySelectorAll('.error-message').forEach(msg => msg.style.display = 'none');
            document.querySelectorAll('input, select, textarea').forEach(input => {
                input.style.borderColor = '#e0e0e0';
            });

            // First Name validation
            const firstName = document.getElementById('firstName');
            if (firstName.value.trim() === '') {
                showError('firstNameError', firstName);
                isValid = false;
            }

            // Last Name validation
            const lastName = document.getElementById('lastName');
            if (lastName.value.trim() === '') {
                showError('lastNameError', lastName);
                isValid = false;
            }

            // Birthdate validation
            const birthdate = document.getElementById('birthdate');
            if (birthdate.value === '') {
                showError('birthdateError', birthdate);
                isValid = false;
            }

            // Gender validation
            const gender = document.getElementById('gender');
            if (gender.value === '') {
                showError('genderError', gender);
                isValid = false;
            }

            // Civil Status validation
            const civilStatus = document.getElementById('civilStatus');
            if (civilStatus.value === '') {
                showError('civilStatusError', civilStatus);
                isValid = false;
            }

            // Address validation
            const address = document.getElementById('address');
            if (address.value.trim() === '') {
                showError('addressError', address);
                isValid = false;
            }

            // Contact Number validation
            const contactNumber = document.getElementById('contactNumber');
            const phoneRegex = /^09\d{9}$/;
            if (!phoneRegex.test(contactNumber.value.replace(/[-\s]/g, ''))) {
                showError('contactError', contactNumber);
                isValid = false;
            }

            // Email validation
            const email = document.getElementById('email');
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value)) {
                showError('emailError', email);
                isValid = false;
            }

            // Username validation
            const username = document.getElementById('username');
            if (username.value.trim() === '') {
                showError('usernameError', username);
                isValid = false;
            }

            // Password validation
            const password = document.getElementById('password');
            if (password.value.length < 8) {
                showError('passwordError', password);
                isValid = false;
            }

            // Confirm Password validation
            const confirmPassword = document.getElementById('confirmPassword');
            if (password.value !== confirmPassword.value) {
                showError('confirmPasswordError', confirmPassword);
                isValid = false;
            }

            // Household Head validation
            const householdHead = document.getElementById('householdHead');
            if (householdHead.value.trim() === '') {
                showError('householdHeadError', householdHead);
                isValid = false;
            }

            if (!isValid) {
                e.preventDefault();
            }
        });

        function showError(errorId, inputElement) {
            document.getElementById(errorId).style.display = 'block';
            inputElement.style.borderColor = '#dc3545';
        }

        // Clear error on input
        document.querySelectorAll('input, select, textarea').forEach(input => {
            input.addEventListener('input', function() {
                this.style.borderColor = '#e0e0e0';
                const errorElement = this.parentElement.querySelector('.error-message');
                if (errorElement) {
                    errorElement.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>