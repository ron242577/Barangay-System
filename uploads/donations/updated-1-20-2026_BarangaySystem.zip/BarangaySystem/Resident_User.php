<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php"; 
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="secretary.css">
<title>Admin Dashboard</title>

</head>

<body>

<div class="sidebar">
  
   <div class="usercontainer">
            <img class="user"src="images/usericon.png" alt="Notification" /> 
           </div>
             
                <h4 class="username"><?= htmlspecialchars($_SESSION["fullname"]) ?></h4> 
             
                    <div class="residentcontainer">
                    <h4 class="resident"><?= htmlspecialchars($_SESSION["role"]) ?></h4>
                    </div>

                        <hr class="hrside">

                            <div class="btncontainer" onclick="window.location.href='Admin_Dashboard.php'">
                            <img class="icon"src="images/dashboard.png" alt="home" /> 
                            <h4 class="text">Dashboard</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Resident_User.php'">
                            <img class="icon"src="images/add-user.png" alt="home" /> 
                            <h4 class="text">Accounts</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Request.php'">
                            <img class="icon"src="images/reqicon.png" alt="request" /> 
                            <h4 class="text">Request</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Report.php'">
                            <img class="icon"src="images/repicon.png" alt="request" /> 
                            <h4 class="text">Report</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Donate.php'">
                            <img class="icon"src="images/dicon.png" alt="request" /> 
                            <h4 class="text">Donate</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Feedback.php'">
                            <img class="icon"src="images/fbicon.png" alt="request" /> 
                            <h4 class="text">Feedback</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Generated-Reports.php'">
    <img class="icon" src="images/add.png" alt="request" /> 
    <h4 class="text">Generated Reports</h4>
</div>

        
                                 <div class="logoutcontainer" onclick="window.location.href='logout.php'">
                                 <h4 class="logout">Logout</h4>
                                 </div>

                                    <hr class="logouthr">
</div>


<div class="content">
<div class="dashboard-header">
  <div class="header-left">
    <img src="images/logo2.png" class="logo">
    <div class="header-text">
      <h2>Barangay Management & E-Services Platform</h2>
    </div>
  </div>

  <img src="images/notification.png" class="header-icon">
</div>

<hr class="green-line">
<div class="table-container">
<table>

<?php
$query = "SELECT 
            id,
            fullname,
            address,
            phone,
            email,
            pwd,
            isf,
            solo_parent
          FROM accounts
          WHERE role = 'resident'
          ORDER BY id DESC";

$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        // Determine category
        if ($row['pwd'] == 1) {
            $category = "PWD";
        } elseif ($row['isf'] == 1) {
            $category = "ISF";
        } elseif ($row['solo_parent'] == 1) {
            $category = "Solo Parent";
        } else {
            $category = "Regular";
        }

        echo "<tr>";
        echo "<td>RES-" . str_pad($row['id'], 3, '0', STR_PAD_LEFT) . "</td>";
        echo "<td>{$row['fullname']}</td>";
        echo "<td>{$category}</td>";
        echo "<td>{$row['address']}</td>";
        echo "<td>{$row['phone']}</td>";
        echo "<td>{$row['email']}</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No registered users found</td></tr>";
}
?>


</table>
</div> <!--END TABLE CONTAINER-->
  
  <div style="display: flex;">
 <div class="botbtn">
<button class="btn-post">Send Message</button>

<button class="btn-report">Generate Report</button>
</div>
</div>
</div>

