<?php
session_start();
include "db.php";

/* =========================
   RESIDENT SUBMIT REQUEST
========================= */
if (isset($_POST['submit'])) {

    $user_id = $_SESSION['user_id'];
    $document = $_POST['docs'];
    $purpose = $_POST['age'];

    $guardian_name = $_POST['guardian_name'] ?? '';
    $guardian_address = $_POST['guardian_address'] ?? '';
    $guardian_contact = $_POST['guardian_contact'] ?? '';

    // Get resident details from accounts
    $stmt = $conn->prepare("SELECT fullname, address FROM accounts WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    $sql = "INSERT INTO requests 
            (user_id, fullname, address, document_type, purpose, guardian_name, guardian_address, guardian_contact)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "isssssss",
        $user_id,
        $user['fullname'],
        $user['address'],
        $document,
        $purpose,
        $guardian_name,
        $guardian_address,
        $guardian_contact
    );
    $stmt->execute();
}

/* =========================
   ADMIN APPROVE REQUEST
========================= */
if (isset($_POST['approve']) && $_SESSION['role'] === 'Admin') {
    $id = (int)$_POST['request_id'];
    $conn->query("UPDATE requests SET status='approved' WHERE request_id=$id");
    header("Location: Request.php");
    exit;
}

/* =========================
   ADMIN DECLINE REQUEST
========================= */
if (isset($_POST['decline']) && $_SESSION['role'] === 'Admin') {
    $id = (int)$_POST['request_id'];
    $conn->query("UPDATE requests SET status='declined' WHERE request_id=$id");
    header("Location: Request.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="secretary.css">
<title>Admin Dashboard</title>

</head>

<body>

<div class="sidebar">
  
   <div class="usercontainer">
            <img class="user"src="images/usericon.png" alt="Notification" /> 
           </div>
             
                <h4 class="username"><?= htmlspecialchars($_SESSION["fullname"]) ?></h4> 
             
                    <div class="residentcontainer">
                    <h4 class="resident"><?= htmlspecialchars($_SESSION["role"]) ?></h4>
                    </div>

                        <hr class="hrside">

                            <div class="btncontainer" onclick="window.location.href='Admin_Dashboard.php'">
                            <img class="icon"src="images/dashboard.png" alt="home" /> 
                            <h4 class="text">Dashboard</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Resident_User.php'">
                            <img class="icon"src="images/add-user.png" alt="home" /> 
                            <h4 class="text">Accounts</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Request.php'">
                            <img class="icon"src="images/reqicon.png" alt="request" /> 
                            <h4 class="text">Request</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Report.php'">
                            <img class="icon"src="images/repicon.png" alt="request" /> 
                            <h4 class="text">Report</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Donate.php'">
                            <img class="icon"src="images/dicon.png" alt="request" /> 
                            <h4 class="text">Donate</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Feedback.php'">
                            <img class="icon"src="images/fbicon.png" alt="request" /> 
                            <h4 class="text">Feedback</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Generated-Reports.php'">
    <img class="icon" src="images/add.png" alt="request" /> 
    <h4 class="text">Generated Reports</h4>
</div>

        
                                 <div class="logoutcontainer" onclick="window.location.href='logout.php'">
                                 <h4 class="logout">Logout</h4>
                                 </div>

                                    <hr class="logouthr">
</div>

<div class="content">
<div class="dashboard-header">
  <div class="header-left">
    <img src="images/logo2.png" class="logo">
    <div class="header-text">
      <h2>Barangay Management & E-Services Platform</h2>
    </div>
  </div>

  <img src="images/notification.png" class="header-icon">
</div>

<hr class="green-line">

<?php
if ($_SESSION['role'] === 'Admin') {

    $sql = "SELECT 
                r.request_id,
                r.document_type,
                r.status,
                r.date_requested,
                r.purpose,
                r.guardian_name,
                r.guardian_address,
                r.guardian_contact,
                a.fullname,
                a.address,
                a.id AS resident_id
            FROM requests r
            INNER JOIN accounts a ON r.user_id = a.id
            ORDER BY r.date_requested DESC";

    $result = $conn->query($sql);

    if (!$result) {
        die("SQL ERROR: " . $conn->error);
    }

    echo "<div class='table-container'>";
    echo "<h2>Document Request Management</h2>";
    echo "<table border='1' cellpadding='10'>";

    echo "
        <tr>
            <th>Resident Name / ID</th>
            <th>Requested Document</th>
            <th>Date Requested</th>
            <th>Request Status</th>
            <th>Actions</th>
        </tr>
    ";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['fullname']) . " (RES-" . str_pad($row['resident_id'], 3, '0', STR_PAD_LEFT) . ")</td>";
            echo "<td>" . htmlspecialchars($row['document_type']) . "</td>";
            echo "<td>" . htmlspecialchars($row['date_requested']) . "</td>";
            echo "<td>" . htmlspecialchars(ucfirst($row['status'])) . "</td>";
            echo "<td>
                <button class='btn-view' onclick='viewRequest(" . $row['request_id'] . ")'>View</button>
                <form method='POST' style='display:inline;'>
                    <input type='hidden' name='request_id' value='" . $row['request_id'] . "'>
                    <button type='submit' class='btn-approve' name='approve' onclick='return confirm(\"Approve this request?\")'>Approve</button>
                </form>
                <form method='POST' style='display:inline;'>
                    <input type='hidden' name='request_id' value='" . $row['request_id'] . "'>
                    <button type='submit' class='btn-decline' name='decline' onclick='return confirm(\"Decline this request?\")'>Decline</button>
                </form>
              </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No requests found</td></tr>";
    }

    echo "</table>";
    echo "</div>";

    // Modals for each request
    $result->data_seek(0); // Reset result pointer
    while ($row = $result->fetch_assoc()) {
        echo "
        <div id='modal-{$row['request_id']}' class='modal'>
            <div class='modal-content'>
                <span class='close' onclick='closeModal({$row['request_id']})'>&times;</span>
                <h2>Request Details</h2>
                <p><strong>Resident Full Name:</strong> " . htmlspecialchars($row['fullname']) . "</p>
                <p><strong>Resident Address:</strong> " . htmlspecialchars($row['address']) . "</p>
                <p><strong>Purpose:</strong> " . htmlspecialchars($row['purpose']) . "</p>
                <p><strong>Requested Document:</strong> " . htmlspecialchars($row['document_type']) . "</p>";
        if (!empty($row['guardian_name'])) {
            echo "<p><strong>Guardian Name:</strong> " . htmlspecialchars($row['guardian_name']) . "</p>";
            echo "<p><strong>Guardian Address:</strong> " . htmlspecialchars($row['guardian_address']) . "</p>";
            echo "<p><strong>Guardian Contact:</strong> " . htmlspecialchars($row['guardian_contact']) . "</p>";
        }
        echo "
            </div>
        </div>";
    }
}
?>

<?php
// Resident view of their own requests
if ($_SESSION['role'] === 'resident') {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT request_id, document_type, status, date_requested FROM requests WHERE user_id = ? ORDER BY date_requested DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<div class='table-container'>";
    echo "<h2>My Document Requests</h2>";
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Request ID</th><th>Document</th><th>Status</th><th>Date Requested</th></tr>";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>REQ-" . str_pad($row['request_id'], 3, '0', STR_PAD_LEFT) . "</td>";
            echo "<td>" . htmlspecialchars($row['document_type']) . "</td>";
            echo "<td>" . htmlspecialchars(ucfirst($row['status'])) . "</td>";
            echo "<td>" . htmlspecialchars($row['date_requested']) . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No requests submitted yet</td></tr>";
    }
    echo "</table>";
    echo "</div>";
}
?>

<style>
.modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgb(0,0,0);
    background-color: rgba(0,0,0,0.4);
}

.modal-content {
    background-color: #fefefe;
    margin: 15% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 500px;
}

.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}

.btn-view {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 4px;
    margin-right: 5px;
}

.btn-approve {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 4px;
    margin-right: 5px;
}

.btn-decline {
    background-color: #dc3545;
    color: white;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 4px;
}

.btn-view:hover { background-color: #0056b3; }
.btn-approve:hover { background-color: #218838; }
.btn-decline:hover { background-color: #c82333; }
</style>

<script>
function viewRequest(id) {
    document.getElementById('modal-' + id).style.display = 'block';
}

function closeModal(id) {
    document.getElementById('modal-' + id).style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.className === 'modal') {
        event.target.style.display = 'none';
    }
}
</script>

</div>
