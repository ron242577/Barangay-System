<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php"; // <-- ADD THIS
?>
<?php
// TOTAL REGISTERED ACCOUNTS
$totalAccountsQuery = "SELECT COUNT(*) AS total FROM accounts";
$totalAccountsResult = $conn->query($totalAccountsQuery);
$totalAccounts = $totalAccountsResult->fetch_assoc()['total'];

// PENDING ACCOUNTS
$pendingAccountsQuery = "SELECT COUNT(*) AS total FROM accounts WHERE status = 'pending'";
$pendingAccountsResult = $conn->query($pendingAccountsQuery);
$pendingAccounts = $pendingAccountsResult->fetch_assoc()['total'];

// PENDING REQUESTS
$pendingRequestsQuery = "SELECT COUNT(*) AS total FROM requests WHERE status = 'pending'";
$pendingRequestsResult = $conn->query($pendingRequestsQuery);
$pendingRequests = $pendingRequestsResult->fetch_assoc()['total'];

// PENDING REPORTS
$pendingReportsQuery = "SELECT COUNT(*) AS total FROM reports WHERE status = 'pending'";
$pendingReportsResult = $conn->query($pendingReportsQuery);
$pendingReports = $pendingReportsResult->fetch_assoc()['total'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="secretary.css">
<title>Admin Dashboard</title>

</head>

<body>

<div class="sidebar">
  
   <div class="usercontainer">
            <img class="user"src="images/usericon.png" alt="Notification" /> 
           </div>
             
                <h4 class="username"><?= htmlspecialchars($_SESSION["fullname"]) ?></h4> 
             
                    <div class="residentcontainer">
                    <h4 class="resident"><?= htmlspecialchars($_SESSION["role"]) ?></h4>
                    </div>

                        <hr class="hrside">

                            <div class="btncontainer" onclick="window.location.href='Admin_Dashboard.php'">
                            <img class="icon"src="images/dashboard.png" alt="home" /> 
                            <h4 class="text">Dashboard</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Resident_User.php'">
                            <img class="icon"src="images/add-user.png" alt="home" /> 
                            <h4 class="text">Accounts</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Request.php'">
                            <img class="icon"src="images/reqicon.png" alt="request" /> 
                            <h4 class="text">Request</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Report.php'">
                            <img class="icon"src="images/repicon.png" alt="request" /> 
                            <h4 class="text">Report</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Donate.php'">
                            <img class="icon"src="images/dicon.png" alt="request" /> 
                            <h4 class="text">Donate</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Feedback.php'">
                            <img class="icon"src="images/fbicon.png" alt="request" /> 
                            <h4 class="text">Feedback</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Generated-Reports.php'">
    <img class="icon" src="images/add.png" alt="request" /> 
    <h4 class="text">Generated Reports</h4>
</div>

        
                                 <div class="logoutcontainer" onclick="window.location.href='logout.php'">
                                 <h4 class="logout">Logout</h4>
                                 </div>

                                    <hr class="logouthr">
</div>

<div class="content">
<div class="dashboard-header">
  <div class="header-left">
    <img src="images/logo2.png" class="logo">
    <div class="header-text">
      <h2>Barangay Management & E-Services Platform</h2>
    </div>
  </div>

  <img src="images/notification.png" class="header-icon">
</div>

<hr class="green-line">


<!--DASHBOARD-->

<div id="card" class="card">

<div class="stat-box">
    <h2><?= $totalAccounts ?></h2>
    <p>Registered Accounts</p>
</div>

<div class="stat-box">
    <h2><?= $pendingAccounts ?></h2>
    <p>Pending Accounts</p>
</div>

<div class="stat-box">
    <h2><?= $pendingRequests ?></h2>
    <p>Pending Requests</p>
</div>

<div class="stat-box">
    <h2><?= $pendingReports ?></h2>
    <p>Pending Report</p>
</div>

</div>


<!--RECENT REQUESTS-->

<div id="card2" class="card2">
  <div class="flex1">
<h1>Recent Document Requests</h1>

<div class="table-container">
<table>
<?php
$recentRequestsQuery = "SELECT 
    r.request_id,
    r.document_type,
    r.status,
    r.date_requested,
    a.fullname
FROM requests r
INNER JOIN accounts a ON r.user_id = a.id
ORDER BY r.date_requested DESC
LIMIT 5";

$recentRequestsResult = $conn->query($recentRequestsQuery);

if ($recentRequestsResult->num_rows > 0) {
    echo "<tr><th>Resident</th><th>Document</th><th>Status</th><th>Date</th></tr>";
    while ($row = $recentRequestsResult->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['fullname']}</td>";
        echo "<td>{$row['document_type']}</td>";
        echo "<td>" . ucfirst($row['status']) . "</td>";
        echo "<td>{$row['date_requested']}</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>No recent requests</td></tr>";
}
?>
</table>
</div>

<div style="display: flex;">
 <div class="botbtn">
<button class="btn-post" onclick="window.location.href='Request.php'">Manage Requests</button>
</div>
</div>
</div>


<!--RESIDENTS USERS-->

<div id="card1" class="card1">
  <div class="flex1">
<h1>Registered Users</h1>

<div class="flex" style="gap:10px; align-items:center;">
 
 <div>
 <label>Category:</label>
<select class="categoryres">
  <option>All</option>
  <option>PWD</option>
  <option>ISF</option>
  <option>Solo Parent</option>
</select>
</div>


<div class="reslabel">
<label>Day:</label>
<select class="categoryres2"onchange="toggleResidentCustom(this)">
  <option value="">Select</option>
  <option>Last 7 Days</option>
  <option>Last 30 Days</option>
  <option>Last Year</option>
  <option value="custom">Custom</option>
</select>
 
<label id="resfr" style="display:none;">From:</label>
<input type="date" id="residentFrom" style="display:none;">
 <label id="restoo" style="display:none;">To:</label>
<input type="date" id="residentTo" style="display:none;">
</div>

<input placeholder="Search"type="search">

</div>

</div>

<!--RESIDENTS USERS TABLE-->

<div class="table-container">
<table>
<?php
$query = "SELECT 
            id,
            fullname,
            address,
            phone,
            email,
            role,
            created_at,
            pwd,
            isf,
            solo_parent
          FROM accounts
          WHERE role = 'resident'
          ORDER BY created_at DESC";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        // Determine Category
        if ($row['pwd'] == 1) {
            $category = "PWD";
        } elseif ($row['isf'] == 1) {
            $category = "ISF";
        } elseif ($row['solo_parent'] == 1) {
            $category = "Solo Parent";
        } else {
            $category = "Regular";
        }

        echo "<tr>";
        echo "<td>RES-" . str_pad($row['id'], 3, '0', STR_PAD_LEFT) . "</td>";
        echo "<td>{$row['fullname']}</td>";
        echo "<td>{$category}</td>";
        echo "<td>{$row['address']}</td>";
        echo "<td>{$row['phone']}</td>";
        echo "<td>{$row['email']}</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No registered users found</td></tr>";
}
?>

</table>
</div> <!--END TABLE CONTAINER-->
  
  <div style="display: flex;">
 <div class="botbtn">
<button class="btn-post">Send Message</button>

<button class="btn-report">Generate Report</button>
</div>
</div>
</div>


</div>

<script>
function toggleResidentCustom(select){
  const from = document.getElementById("residentFrom");
  const to = document.getElementById("residentTo");
  const fr = document.getElementById("resfr");   
  const too = document.getElementById("restoo");
  
  if(select.value === "custom"){
    from.style.display = "inline-block";
    to.style.display = "inline-block";
    fr.style.display = "inline-block";
    too.style.display = "inline-block";
  } else {
    from.style.display = "none";
    to.style.display = "none";
    fr.style.display = "none";
    too.style.display = "none";
  }
}


function toggleApprovedCustom(select){
  const from = document.getElementById("approvedFrom");
  const to = document.getElementById("approvedTo");
  const too = document.getElementById("too");
  const fr = document.getElementById("fr");
  if(select.value === "custom"){
    from.style.display = "inline-block";
    to.style.display = "inline-block";
     too.style.display = "inline-block";
      fr.style.display = "inline-block";
  } else {
    from.style.display = "none";
    to.style.display = "none";
    too.style.display = "none";
    fr.style.display = "none";
  }
}
function toggleReportCustom(select){
  const from = document.getElementById("reportFrom");
  const to = document.getElementById("reportTo");
  const too = document.getElementById("reptoo");
  const fr = document.getElementById("repfr");
  if(select.value === "custom"){
    from.style.display = "inline-block";
    to.style.display = "inline-block";
     too.style.display = "inline-block";
      fr.style.display = "inline-block";
  } else {
    from.style.display = "none";
    to.style.display = "none";
    too.style.display = "none";
    fr.style.display = "none";
  }
}
function toggleFeedbackCustom(select){
  const from = document.getElementById("feedbackFrom");
  const to = document.getElementById("feedbackTo");
  const too = document.getElementById("fbtoo");
  const fr = document.getElementById("fbfr");
  if(select.value === "custom"){
    from.style.display = "inline-block";
    to.style.display = "inline-block";
     too.style.display = "inline-block";
      fr.style.display = "inline-block";
  } else {
    from.style.display = "none";
    to.style.display = "none";
    too.style.display = "none";
    fr.style.display = "none";
  }
}
function toggleDonateCustom(select){
  const from = document.getElementById("donateFrom");
  const to = document.getElementById("donateTo");
  const too = document.getElementById("dtoo");
  const fr = document.getElementById("dfr");
  if(select.value === "custom"){
    from.style.display = "inline-block";
    to.style.display = "inline-block";
     too.style.display = "inline-block";
      fr.style.display = "inline-block";
  } else {
    from.style.display = "none";
    to.style.display = "none";
    too.style.display = "none";
    fr.style.display = "none";
  }
}
    function showDashboard() {
    document.getElementById("card").style.display = "block";
     document.getElementById("card1").style.display = "block";
    document.getElementById("cardrequest").style.display = "none";
    document.getElementById("cardreport").style.display = "none";
    document.getElementById("carddonate").style.display = "none";
    document.getElementById("cardfeedback").style.display = "none";
    document.getElementById("cardaccounts").style.display = "none";
       document.getElementById("cardgeneratedreport").style.display = "none";
}
    function showAccounts() {
    document.getElementById("card").style.display = "none";
     document.getElementById("card1").style.display = "none";
    document.getElementById("cardrequest").style.display = "none";
    document.getElementById("cardreport").style.display = "none";
    document.getElementById("carddonate").style.display = "none";
    document.getElementById("cardfeedback").style.display = "none";
    document.getElementById("cardaccounts").style.display = "block";
       document.getElementById("cardgeneratedreport").style.display = "none";
}
    function showRequest() {
    document.getElementById("card").style.display = "none";
     document.getElementById("card1").style.display = "none";
    document.getElementById("cardrequest").style.display = "block";
    document.getElementById("cardreport").style.display = "none";
    document.getElementById("carddonate").style.display = "none";
    document.getElementById("cardfeedback").style.display = "none";
    document.getElementById("cardaccounts").style.display = "none";
       document.getElementById("cardgeneratedreport").style.display = "none";
}
    function showReport() {
    document.getElementById("card").style.display = "none";
      document.getElementById("card1").style.display = "none";
    document.getElementById("cardrequest").style.display = "none";
    document.getElementById("cardreport").style.display = "block";
    document.getElementById("carddonate").style.display = "none";
    document.getElementById("cardfeedback").style.display = "none";
    document.getElementById("cardaccounts").style.display = "none";
       document.getElementById("cardgeneratedreport").style.display = "none";
}
    function showDonate() {
    document.getElementById("card").style.display = "none";
      document.getElementById("card1").style.display = "none";
    document.getElementById("cardrequest").style.display = "none";
    document.getElementById("cardreport").style.display = "none";
    document.getElementById("carddonate").style.display = "block";
    document.getElementById("cardfeedback").style.display = "none";
    document.getElementById("cardaccounts").style.display = "none";
       document.getElementById("cardgeneratedreport").style.display = "none";
}
    function showFeedback() {
    document.getElementById("card").style.display = "none";
      document.getElementById("card1").style.display = "none";
    document.getElementById("cardrequest").style.display = "none";
    document.getElementById("cardreport").style.display = "none";
    document.getElementById("carddonate").style.display = "none";
    document.getElementById("cardfeedback").style.display = "block";
    document.getElementById("cardaccounts").style.display = "none";
      document.getElementById("cardgeneratedreport").style.display = "none";
}
    function showGeneratedReport() {
    document.getElementById("card").style.display = "none";
      document.getElementById("card1").style.display = "none";
    document.getElementById("cardrequest").style.display = "none";
    document.getElementById("cardreport").style.display = "none";
    document.getElementById("carddonate").style.display = "none";
    document.getElementById("cardfeedback").style.display = "none";
    document.getElementById("cardaccounts").style.display = "none";
    document.getElementById("cardgeneratedreport").style.display = "block";
}
</script>

</body>
</html>
