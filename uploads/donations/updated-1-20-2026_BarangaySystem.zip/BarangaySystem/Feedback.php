<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="secretary.css">
<title>Admin Dashboard</title>

</head>

<body>

<div class="sidebar">
  
   <div class="usercontainer">
            <img class="user"src="images/usericon.png" alt="Notification" /> 
           </div>
             
                <h4 class="username"><?= htmlspecialchars($_SESSION["fullname"]) ?></h4> 
             
                    <div class="residentcontainer">
                    <h4 class="resident"><?= htmlspecialchars($_SESSION["role"]) ?></h4>
                    </div>

                        <hr class="hrside">

                            <div class="btncontainer" onclick="window.location.href='Admin_Dashboard.php'">
                            <img class="icon"src="images/dashboard.png" alt="home" /> 
                            <h4 class="text">Dashboard</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Resident_User.php'">
                            <img class="icon"src="images/add-user.png" alt="home" /> 
                            <h4 class="text">Accounts</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Request.php'">
                            <img class="icon"src="images/reqicon.png" alt="request" /> 
                            <h4 class="text">Request</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Report.php'">
                            <img class="icon"src="images/repicon.png" alt="request" /> 
                            <h4 class="text">Report</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Donate.php'">
                            <img class="icon"src="images/dicon.png" alt="request" /> 
                            <h4 class="text">Donate</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Feedback.php'">
                            <img class="icon"src="images/fbicon.png" alt="request" /> 
                            <h4 class="text">Feedback</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Generated-Reports.php'">
    <img class="icon" src="images/add.png" alt="request" /> 
    <h4 class="text">Generated Reports</h4>
</div>

        
                                 <div class="logoutcontainer" onclick="window.location.href='logout.php'">
                                 <h4 class="logout">Logout</h4>
                                 </div>

                                    <hr class="logouthr">
</div>

<div class="content">
<div class="dashboard-header">
  <div class="header-left">
    <img src="images/logo2.png" class="logo">
    <div class="header-text">
      <h2>Barangay Management & E-Services Platform</h2>
    </div>
  </div>

  <img src="images/notification.png" class="header-icon">
</div>

<hr class="green-line">

<!--FEEDBACK-->


<div id="cardfeedback" class="cardfeedback">
 
<div class="flex1" style="align-items:center; gap: 10px; margin-bottom:10px; flex-wrap:wrap;">
  <div class="h11">
  <h1>Feedback</h1>
</div>

 <div class="flex3">

  <div>
  <label>Status</label>
  <select class="custom8">
    <option>New</option>
    <option>Reviewed</option>
  </select>
</div>

  <label class="day">Day:</label>
  <select class="custom9" onchange="toggleFeedbackCustom(this)">
    <option value="">Select</option>
    <option>Last 7 Days</option>
    <option>Last 30 Days</option>
    <option>Last Year</option>
    <option value="custom">Custom</option>
  </select>

   <label id="fbfr" style="display:none;">From:</label>
  <input type="date" id="feedbackFrom" style="display:none;">
   <label id="fbtoo" style="display:none;">To:</label>
  <input type="date" id="feedbackTo" style="display:none;">


   <div class="reslabel"></div>

 <input placeholder="Search"type="search">

</div>

</div>

<!--FEEDBACK TABLE-->

<div class="table-container">
 
<table>
<tr>
  <th>Request ID</th>
    <th>Resident ID</th>
  <th>Resident Name</th>
  <th>Status</th>
  <th>Actions</th>
</tr>

<tr>
  <td>REQ-001</td>
   <td>RES-001</td>
  <td>Juan Dela Cruz</td>
   <td>New</td>
  <td>
    <button class="btn-view">View</button>
    <button class="btn-approve">Approve</button>
    <button class="btn-decline">Decline</button>
  </td>
</tr>

</table>

</div> <!--END TABLE CONTAINER-->

</div>

<script>
document.getElementById("cardfeedback").style.display = "block";
</script>

</div>
</body>
</html>