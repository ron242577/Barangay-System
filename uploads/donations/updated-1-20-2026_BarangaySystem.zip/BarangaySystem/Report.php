<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="secretary.css">
<title>Admin Dashboard</title>

</head>

<body>

<div class="sidebar">
  
   <div class="usercontainer">
            <img class="user"src="images/usericon.png" alt="Notification" /> 
           </div>
             
                <h4 class="username"><?= htmlspecialchars($_SESSION["fullname"]) ?></h4> 
             
                    <div class="residentcontainer">
                    <h4 class="resident"><?= htmlspecialchars($_SESSION["role"]) ?></h4>
                    </div>

                        <hr class="hrside">

                            <div class="btncontainer" onclick="window.location.href='Admin_Dashboard.php'">
                            <img class="icon"src="images/dashboard.png" alt="home" /> 
                            <h4 class="text">Dashboard</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Resident_User.php'">
                            <img class="icon"src="images/add-user.png" alt="home" /> 
                            <h4 class="text">Accounts</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Request.php'">
                            <img class="icon"src="images/reqicon.png" alt="request" /> 
                            <h4 class="text">Request</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Report.php'">
                            <img class="icon"src="images/repicon.png" alt="request" /> 
                            <h4 class="text">Report</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Donate.php'">
                            <img class="icon"src="images/dicon.png" alt="request" /> 
                            <h4 class="text">Donate</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Feedback.php'">
                            <img class="icon"src="images/fbicon.png" alt="request" /> 
                            <h4 class="text">Feedback</h4>
                            </div>

                            <div class="btncontainer" onclick="window.location.href='Generated-Reports.php'">
    <img class="icon" src="images/add.png" alt="request" /> 
    <h4 class="text">Generated Reports</h4>
</div>

        
                                 <div class="logoutcontainer" onclick="window.location.href='logout.php'">
                                 <h4 class="logout">Logout</h4>
                                 </div>

                                    <hr class="logouthr">
</div>

<div class="content">
<div class="dashboard-header">
  <div class="header-left">
    <img src="images/logo2.png" class="logo">
    <div class="header-text">
      <h2>Barangay Management & E-Services Platform</h2>
    </div>
  </div>

  <img src="images/notification.png" class="header-icon">
</div>

<hr class="green-line">


<!--REPORT-->

<div id="cardreport" class="cardreport">
  <div class="flex1" style="align-items:center; gap: 10px; margin-bottom:10px; flex-wrap:wrap;">
  <div class="h11">
  <h1>Report</h1>
</div>

 <div class="flex3">

   <label>Status:</label>
  <select class="custom3">
    <option>Pending</option>
    <option>Resolved</option>
    <option>Ongoing</option>
  </select>

  <label class="day">Day:</label>
  <select class="custom4" onchange="toggleReportCustom(this)">
    <option value="">Select</option>
    <option>Last 7 Days</option>
    <option>Last 30 Days</option>
    <option>Last Year</option>
    <option value="custom">Custom</option>
  </select>

    <label id="repfr" style="display:none;">From:</label>
  <input type="date" id="reportFrom" style="display:none;">
   <label id="reptoo" style="display:none;">To:</label>
  <input class="input1"type="date" id="reportTo" style="display:none;">

  <label>Type:</label>
  <select class="custom5">
    <option>All</option>
    <option>Noise Disturbance</option>
    <option>Illegal Parking</option>
    <option>Loitering</option>
    <option>Vandalism</option>
    <option>Domestic Dispute</option>
    <option>Suspicious Activity</option>
    <option>Others</option>
  </select>

 <div class="reslabel"></div>
 <input placeholder="Search"type="search">

</div>
</div>

<!--REPORT TABLE-->

<div class="table-container">
<table>
<tr>
  <th>Report ID</th>
  <th>Reporter Name</th>
  <th>Status</th>
  <th>Reason</th>
  <th>Action</th>
</tr>
<tr>
  <td>REP-001</td>
  <td>Juan Dela Cruz</td>
  <td>Pending</td>
  <td>Noise Complaint</td>
  <td>
    <button class="btn-view">View</button>
    <button class="btn-approve">Approve</button>
    <button class="btn-decline">Decline</button>
  </td>
</tr>

</table>
</div> <!--END TABLE CONTAINER-->

<div style="display: flex;">
  <div class="botbtn">
  <button class="btn-report">Generate Report</button>
  </div>
</div>

<script>
document.getElementById("cardreport").style.display = "block";
</script>

</body>
